# ExamFusion Prep Android

Official Android WebView app for [examfusionprep.com](https://examfusionprep.com/).

## App details

- App name: ExamFusion Prep
- Package: `com.examfusionprep.app`
- Version: `1.0.0` (version code 1)
- Minimum Android: Android 7.0 (API 24)
- Target Android: Android 15 (API 35)

## Included behavior

- Native splash screen and adaptive launcher icon using the existing ExamFusion Prep logo
- Secure HTTPS-only WebView
- Website back navigation
- File upload picker and Android Downloads integration
- Telegram, YouTube, phone, email, and other external links open in their appropriate apps
- Deep-link support for `examfusionprep.com`
- Hindi/English offline and page-error screen with retry
- Cookie, local-storage, zoom, and responsive-page support

## Building

Open this folder in Android Studio with JDK 17 and Android SDK 35 installed. Use the separate signing backup when producing future updates. Every update must retain the same package name and signing key, and must increment `versionCode`.
